# shopping/urls.py

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include  # ← include added

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('shop.urls')),     # ← shop app URLs
    path('cart/', include('cart.urls')),  # ← cart app URLs
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
